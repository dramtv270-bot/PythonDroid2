pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositories { google(); mavenCentral(); maven { url = uri("https://chaquo.com/maven") } }
}
rootProject.name = "PythonDroid"
include(":app")
