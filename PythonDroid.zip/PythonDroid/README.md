# PythonDroid
1. Create a GitHub repo, upload this folder's contents (keep the .github folder).
2. Open the Actions tab > "Build APK" > wait for green.
3. Download the PythonDroid-apk artifact, unzip, install the .apk on your phone.
