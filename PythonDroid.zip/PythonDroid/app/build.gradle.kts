plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}
android {
    namespace = "com.pythondroid"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.pythondroid"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            install("numpy")
            install("scipy")
            install("pandas")
            install("matplotlib")
            install("pillow")
            install("requests")
            install("sympy")
            install("beautifulsoup4")
            // Need more size/features? Add: install("scikit-learn"), install("opencv-python-headless")
        }
    }
}
dependencies { implementation("androidx.appcompat:appcompat:1.7.0") }
