import sys, os, re, json, ctypes, threading, traceback, zipfile, shutil, builtins
import urllib.request, importlib, importlib.metadata as md

SITE = ""
_tid = None


def setup(site):
    global SITE
    SITE = site
    os.makedirs(site, exist_ok=True)
    if site not in sys.path:
        sys.path.insert(0, site)
    os.environ["MPLBACKEND"] = "Agg"


class _W:
    def __init__(self, f): self.f = f
    def write(self, s): self.f(s); return len(s)
    def flush(self): pass


def run(code, bridge, cache):
    global _tid
    _tid = threading.get_ident()
    old = (sys.stdout, sys.stderr, builtins.input)
    sys.stdout, sys.stderr = _W(bridge.out), _W(bridge.err)
    builtins.input = lambda p="": bridge.ask(str(p))
    try:
        exec(compile(code, "<script>", "exec"), {"__name__": "__main__"})
    except KeyboardInterrupt:
        bridge.err("\n[stopped]\n")
    except BaseException:
        bridge.err(traceback.format_exc())
    finally:
        sys.stdout, sys.stderr, builtins.input = old
        _tid = None
    plt = sys.modules.get("matplotlib.pyplot")
    if plt is not None and plt.get_fignums():
        p = os.path.join(cache, "plot.png")
        plt.savefig(p, dpi=110)
        plt.close("all")
        return p
    return ""


def stop():
    if _tid:
        ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(_tid), ctypes.py_object(KeyboardInterrupt))


def pip_install(name, bridge, seen=None):
    seen = seen if seen is not None else set()
    key = name.strip().lower().replace("_", "-")
    if not key or key in seen:
        return
    seen.add(key)
    try:
        md.version(key)
        bridge.out(f"{key}: already available\n")
        return
    except Exception:
        pass
    try:
        d = json.load(urllib.request.urlopen(f"https://pypi.org/pypi/{key}/json", timeout=30))
        w = next(u for u in d["urls"] if u["filename"].endswith("-none-any.whl"))
    except StopIteration:
        bridge.err(f"{key}: no pure-Python wheel (native packages must be bundled at build time)\n")
        return
    except Exception as e:
        bridge.err(f"{key}: {e}\n")
        return
    bridge.out(f"Installing {key} {d['info']['version']}...\n")
    tmp = os.path.join(SITE, "_w.whl")
    urllib.request.urlretrieve(w["url"], tmp)
    with zipfile.ZipFile(tmp) as z:
        z.extractall(SITE)
    os.remove(tmp)
    importlib.invalidate_caches()
    for r in d["info"].get("requires_dist") or []:
        if ";" in r:
            continue
        pip_install(re.split(r"[ <>=!~(\[]", r)[0], bridge, seen)


def packages():
    return sorted(f"{d.metadata['Name']} {d.version}" for d in md.distributions() if d.metadata["Name"])


def uninstall(name):
    try:
        d = md.distribution(name)
    except Exception:
        return "not found"
    if not str(d._path).startswith(SITE):
        return "bundled package, can't be removed"
    for f in d.files or []:
        p = os.path.join(SITE, str(f))
        if os.path.isfile(p):
            os.remove(p)
    shutil.rmtree(str(d._path), ignore_errors=True)
    importlib.invalidate_caches()
    return "removed " + name
