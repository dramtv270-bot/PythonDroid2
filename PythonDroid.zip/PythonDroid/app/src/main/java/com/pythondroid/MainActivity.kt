package com.pythondroid

import android.app.AlertDialog
import android.content.Intent
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.*
import android.text.style.ForegroundColorSpan
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.util.concurrent.CountDownLatch

class MainActivity : AppCompatActivity() {
    private lateinit var editor: EditText
    private lateinit var console: TextView
    private lateinit var scroll: ScrollView
    private lateinit var tabs: Spinner
    private lateinit var dir: File
    private lateinit var py: PyObject
    private val open = mutableListOf<File>()
    private var idx = 0
    private var running = false
    private val bridge = Bridge()

    inner class Bridge {
        fun out(s: String) { runOnUiThread { append(s, null) } }
        fun err(s: String) { runOnUiThread { append(s, Color.RED) } }
        fun ask(prompt: String): String {
            val latch = CountDownLatch(1)
            var res = ""
            runOnUiThread {
                val et = EditText(this@MainActivity)
                AlertDialog.Builder(this@MainActivity).setTitle(prompt.ifEmpty { "Input" })
                    .setView(et).setCancelable(false)
                    .setPositiveButton("OK") { _, _ -> res = et.text.toString(); latch.countDown() }.show()
            }
            latch.await()
            runOnUiThread { append("$res\n", null) }
            return res
        }
    }

    private val kw = Regex("\\b(def|class|import|from|as|if|elif|else|for|while|return|try|except|finally|with|in|not|and|or|is|lambda|pass|break|continue|yield|raise|None|True|False|print)\\b")
    private val str = Regex("(\"[^\"\\n]*\"|'[^'\\n]*')")
    private val com = Regex("#.*")
    private val num = Regex("\\b\\d+(\\.\\d+)?\\b")

    private fun highlight(e: Editable) {
        e.getSpans(0, e.length, ForegroundColorSpan::class.java).forEach { e.removeSpan(it) }
        for ((r, c) in listOf(kw to 0xFFFF9800.toInt(), num to 0xFF2196F3.toInt(), str to 0xFF4CAF50.toInt(), com to 0xFF9E9E9E.toInt()))
            r.findAll(e).forEach { e.setSpan(ForegroundColorSpan(c), it.range.first, it.range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
    }

    private val templates = linkedMapOf(
        "Hello world" to "print('Hello from PythonDroid!')\n",
        "Input demo" to "name = input('Your name? ')\nprint(f'Hi {name}!')\n",
        "NumPy" to "import numpy as np\na = np.random.rand(3, 3)\nprint(a)\nprint(np.linalg.inv(a))\n",
        "Pandas" to "import pandas as pd\ndf = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})\nprint(df.describe())\n",
        "Matplotlib plot" to "import matplotlib.pyplot as plt\nimport numpy as np\nx = np.linspace(0, 10, 200)\nplt.plot(x, np.sin(x))\nplt.title('sin(x)')\n",
        "Requests" to "import requests\nr = requests.get('https://api.github.com')\nprint(r.status_code, r.headers['content-type'])\n",
        "SymPy" to "from sympy import symbols, diff, integrate\nx = symbols('x')\nprint(diff(x**3, x), integrate(x**2, x))\n"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        py = Python.getInstance().getModule("runner")
        py.callAttr("setup", File(filesDir, "site").path)
        dir = File(filesDir, "scripts").apply { mkdirs() }
        if (dir.listFiles().isNullOrEmpty()) File(dir, "main.py").writeText("print('Hello from PythonDroid!')\n")

        tabs = Spinner(this)
        editor = EditText(this).apply {
            typeface = Typeface.MONOSPACE; gravity = Gravity.TOP; textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setHorizontallyScrolling(true)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable) = highlight(e)
            })
        }
        console = TextView(this).apply {
            typeface = Typeface.MONOSPACE; setTextColor(0xFFB9F6CA.toInt()); setPadding(16, 16, 16, 16)
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply { setBackgroundColor(0xFF121212.toInt()); addView(console) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(tabs)
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        tabs.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != idx) { save(); idx = pos; editor.setText(open[pos].readText()) }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        openFile(dir.listFiles()!!.sorted().first())
        val ver = Python.getInstance().getModule("sys").get("version").toString().substringBefore(" ")
        append("PythonDroid ready. Python $ver\n", Color.CYAN)
    }

    private fun save() { if (open.isNotEmpty()) open[idx].writeText(editor.text.toString()) }
    override fun onPause() { super.onPause(); save() }

    private fun openFile(f: File) {
        save()
        if (f !in open) open.add(f)
        idx = open.indexOf(f)
        tabs.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, open.map { it.name })
        tabs.setSelection(idx)
        editor.setText(f.readText())
    }

    private fun append(s: String, color: Int?) {
        val sp = SpannableString(s)
        if (color != null) sp.setSpan(ForegroundColorSpan(color), 0, s.length, 0)
        console.append(sp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun run() {
        if (running) return
        save(); running = true
        append("\n> ${open[idx].name}\n", Color.CYAN)
        val code = editor.text.toString()
        Thread {
            val plot = py.callAttr("run", code, bridge, cacheDir.path).toString()
            runOnUiThread { running = false; append("[done]\n", Color.CYAN); if (plot.isNotEmpty()) showPlot(plot) }
        }.start()
    }

    private fun showPlot(p: String) {
        val iv = ImageView(this).apply { setBackgroundColor(Color.WHITE); setImageBitmap(BitmapFactory.decodeFile(p)) }
        AlertDialog.Builder(this).setView(iv).setPositiveButton("Close", null).show()
    }

    private fun ask(title: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString().trim()) }.setNegativeButton("Cancel", null).show()
    }

    private fun newFile(name: String, content: String) {
        var n = name.ifEmpty { "script" }.removeSuffix(".py")
        var f = File(dir, "$n.py"); var i = 1
        while (f.exists()) f = File(dir, "${n}_${i++}.py")
        f.writeText(content); openFile(f)
    }

    private val items = listOf("Run", "Stop", "New", "Files", "Templates", "Install library", "Packages", "Last plot", "Share", "Toggle theme", "Clear console", "Save")

    override fun onCreateOptionsMenu(m: Menu): Boolean {
        items.forEachIndexed { i, t -> m.add(0, i, i, t).setShowAsAction(if (i < 2) MenuItem.SHOW_AS_ACTION_ALWAYS else MenuItem.SHOW_AS_ACTION_NEVER) }
        return true
    }

    override fun onOptionsItemSelected(mi: MenuItem): Boolean {
        when (mi.itemId) {
            0 -> run()
            1 -> py.callAttr("stop")
            2 -> ask("File name") { newFile(it, "") }
            3 -> {
                val fs = dir.listFiles()!!.sorted()
                AlertDialog.Builder(this).setTitle("Files").setItems(fs.map { it.name }.toTypedArray()) { _, i -> openFile(fs[i]) }
                    .setNeutralButton("Delete current") { _, _ ->
                        if (open.size > 1) { val f = open.removeAt(idx); f.delete(); idx = 0; openFile(open[0]) }
                    }.show()
            }
            4 -> {
                val names = templates.keys.toList()
                AlertDialog.Builder(this).setTitle("Templates").setItems(names.toTypedArray()) { _, i -> newFile(names[i].replace(" ", "_").lowercase(), templates[names[i]]!!) }.show()
            }
            5 -> ask("Package name (pure-Python from PyPI)") { n -> Thread { py.callAttr("pip_install", n, bridge); bridge.out("[pip finished]\n") }.start() }
            6 -> {
                val pk = py.callAttr("packages").asList().map { it.toString() }
                AlertDialog.Builder(this).setTitle("Packages (tap to uninstall)").setItems(pk.toTypedArray()) { _, i ->
                    Toast.makeText(this, py.callAttr("uninstall", pk[i].substringBefore(" ")).toString(), Toast.LENGTH_SHORT).show()
                }.show()
            }
            7 -> File(cacheDir, "plot.png").takeIf { it.exists() }?.let { showPlot(it.path) } ?: Toast.makeText(this, "No plot yet", Toast.LENGTH_SHORT).show()
            8 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, editor.text.toString()), "Share script"))
            9 -> {
                val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
                AppCompatDelegate.setDefaultNightMode(if (dark) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES)
            }
            10 -> console.text = ""
            11 -> { save(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() }
        }
        return true
    }
}
